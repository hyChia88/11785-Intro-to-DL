def question_1():
    return NotImplemented


def question_2():
    return NotImplemented


def question_3():
    return NotImplemented


def question_4():
    return NotImplemented


def question_5():
    return NotImplemented
