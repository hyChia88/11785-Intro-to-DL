def question_1():
    # return ""
    raise NotImplementedError


def question_2():
    # return ""
    raise NotImplementedError


def question_3():
    # return ""
    raise NotImplementedError



def question_4():
    # return ""
    raise NotImplementedError


def question_5():
    # return ""
    raise NotImplementedError

